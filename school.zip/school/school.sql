-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2016 at 06:15 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `school`
--
CREATE DATABASE IF NOT EXISTS `school` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `school`;

-- --------------------------------------------------------

--
-- Table structure for table `children`
--

CREATE TABLE IF NOT EXISTS `children` (
  `child_id` int(11) NOT NULL AUTO_INCREMENT,
  `Roll_no` int(11) DEFAULT NULL,
  `child_name` varchar(20) NOT NULL,
  `grade` varchar(5) NOT NULL,
  PRIMARY KEY (`child_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `children`
--

INSERT INTO `children` (`child_id`, `Roll_no`, `child_name`, `grade`) VALUES
(3, 1105, 'Manoj', 'LKG'),
(4, 1106, 'praveen', 'UKG'),
(5, 123, 'Sekhar', 'LKG'),
(6, 124, 'Farook', 'UKG');

-- --------------------------------------------------------

--
-- Table structure for table `device_info`
--

CREATE TABLE IF NOT EXISTS `device_info` (
  `device_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `mobile_device_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`device_info_id`),
  KEY `user_id` (`user_id`),
  KEY `mobile_device_id` (`mobile_device_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `device_info`
--

INSERT INTO `device_info` (`device_info_id`, `user_id`, `mobile_device_id`) VALUES
(22, 1, 22),
(23, 12, 23),
(24, 17, 24),
(25, 18, 25);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(255) NOT NULL,
  `event_info` text NOT NULL,
  `group_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE IF NOT EXISTS `group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) NOT NULL,
  `description` varchar(20) NOT NULL,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `staff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  KEY `group_name` (`group_name`),
  KEY `description` (`description`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`group_id`, `group_name`, `description`, `created_date`, `staff_id`) VALUES
(7, 'Children''s day', 'On November 14th 201', '2016-04-19 16:04:09', 6),
(8, 'Teacher''s day', 'On September 5th 201', '2016-04-19 16:04:29', 4),
(9, 'Annual day', 'On December 4th', '2016-04-19 16:43:49', 2),
(10, 'Holiday', 'From 25 april to 2nd', '2016-04-20 10:48:13', 4),
(11, 'Haloween', 'October last', '2016-04-29 13:35:29', 5),
(12, 'Red day', 'have to come in red', '2016-05-03 17:20:56', 3),
(13, 'black day', 'have to be in black ', '2016-05-03 17:58:00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `group_info`
--

CREATE TABLE IF NOT EXISTS `group_info` (
  `group_id` int(11) DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  KEY `group_id` (`group_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group_info`
--

INSERT INTO `group_info` (`group_id`, `parent_id`) VALUES
(9, 5),
(7, 1),
(8, 2),
(7, 3),
(8, 3),
(8, 7),
(9, 7);

-- --------------------------------------------------------

--
-- Table structure for table `mobile_device`
--

CREATE TABLE IF NOT EXISTS `mobile_device` (
  `mobile_device_id` int(11) NOT NULL AUTO_INCREMENT,
  `location` point NOT NULL,
  `lat` decimal(10,8) NOT NULL,
  `lng` decimal(10,0) NOT NULL,
  `application_version` varchar(255) NOT NULL,
  `device_model` varchar(255) NOT NULL,
  `device_platform` varchar(255) NOT NULL,
  `device_uuid` int(11) NOT NULL,
  `device_verson` varchar(255) NOT NULL,
  `gcm_id` varchar(250) NOT NULL,
  `device_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`mobile_device_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `mobile_device`
--

INSERT INTO `mobile_device` (`mobile_device_id`, `location`, `lat`, `lng`, `application_version`, `device_model`, `device_platform`, `device_uuid`, `device_verson`, `gcm_id`, `device_status`) VALUES
(1, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '321', '321', '7421', 456, '123', '321', NULL),
(2, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(3, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(4, '\0\0\0\0\0\0\0������F@�G�z�F@', '99.99999999', '123', '123', '123', '123', 123, '123', '123', NULL),
(5, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '12345', '143', 456, '1235', '345', NULL),
(6, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(7, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(8, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(9, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(10, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(11, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(12, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(13, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(14, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(15, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(16, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(17, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(18, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(19, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(20, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(21, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL),
(22, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '3212', '3212', '7421', 456, '123', '3212', NULL),
(23, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8551', '85567', '7421', 456, '8564', '3451', NULL),
(24, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '1234', '1234', '7421', 456, '1234', '1234', NULL),
(25, '\0\0\0\0\0\0\0������F@�G�z�F@', '45.70000000', '46', '8556', '85567', '7421', 456, '8564', '345', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE IF NOT EXISTS `parents` (
  `parent_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_name` varchar(20) NOT NULL,
  `parent_address` text NOT NULL,
  `mobile_number` varchar(12) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`parent_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`parent_id`, `parent_name`, `parent_address`, `mobile_number`, `user_id`) VALUES
(1, 'suresh', 'trichy', '9874561204', 6),
(2, 'venkat', 'thanjore', '8974561235', 7),
(3, 'Sundar', 'Gujarat', '9489773130', 9),
(4, 'jaleel', 'Coimbatore', '8765491230', 10),
(5, 'yyy-sekhar', 'Goplapuram', '45661237890', 12),
(6, 'pandian', 'holland', '4561278903', 16),
(7, 'vishwa', 'tokyo', '9874561230', 17);

-- --------------------------------------------------------

--
-- Table structure for table `parents_children`
--

CREATE TABLE IF NOT EXISTS `parents_children` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  KEY `parent_id` (`parent_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parents_children`
--

INSERT INTO `parents_children` (`parent_id`, `child_id`) VALUES
(1, 3),
(2, 4),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 5);

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE IF NOT EXISTS `photos` (
  `photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `photo_url` varchar(60) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`photo_id`),
  KEY `group_id` (`group_id`),
  KEY `created_by` (`created_by`),
  KEY `created_by_2` (`created_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`photo_id`, `group_id`, `photo_url`, `created_by`, `created_date`) VALUES
(2, 12, 'Android Tablet-100_1462627454.png', 15, '2016-05-07 18:54:14'),
(3, 12, 'Android_edited_1462627488.jpg', 15, '2016-05-07 18:54:48');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE IF NOT EXISTS `school` (
  `school_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(255) NOT NULL,
  `school_address` text NOT NULL,
  `phone_number` int(11) NOT NULL,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `school_user`
--

CREATE TABLE IF NOT EXISTS `school_user` (
  `school_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`school_user_id`),
  KEY `school_id` (`school_id`),
  KEY `user_id` (`user_id`),
  KEY `user_id_2` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(20) NOT NULL,
  `designation` varchar(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  KEY `staff_id` (`staff_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_name`, `designation`, `user_id`) VALUES
(2, 'Zubair', '3rd Standard Teacher', NULL),
(3, 'tyty', '5th Standard Teacher', NULL),
(4, 'Fouzudeen', '6th Standard teacher', NULL),
(5, 'varathan', '12th', 15),
(6, 'paul', '6th Standard teacher', 18);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `role_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', '5vNsIBOWXulXDfV97bPpuO497CR7Xud9', '$2y$13$8CkanQf5gdaEXFKGBovrwuiDrA0P50REb/iWBZ4fp6cM1BeNPvQia', NULL, 'vignesh.kodebees@gmail.com', 1, 10, '2016-04-21 12:24:59', '2016-04-29 13:04:32'),
(2, 'hari', 'oM3dFelUO4YWJP76TtA6IdteH-FXO4Xb', '$2y$13$VuNFP2eR4Yyrb3uxeUyVauDaBK2pkMNZjR/XecE60ubgE9uwpppmC', NULL, 'hari.kodebees@gmail.com', 3, 10, '2016-04-21 12:28:31', '2016-04-29 13:04:04'),
(3, 'kathir', 'JsmMbMKVsaielTPGLqwUhA2z9mudyLoj', '$2y$13$cVqe3YN1A8oZN1VJPGXAGu6QX3M7ZwKzC.lxeeevy.T1OM3nSncfq', NULL, 'kathir@gmail.com', 3, 10, '2016-04-23 17:01:40', '2016-04-29 13:04:08'),
(4, 'vignesh', 'LWNkX5xbXXBn2RileI6YB8v2ywGJlamF', '$2y$13$muvUh./GLdcwy2uBZ7Uv.uvS.tJA5pNv0KekCmYY0MXLV7Mf2Ky3O', NULL, 'vignesh@gmail.com', 3, 10, '0000-00-00 00:00:00', '2016-04-29 13:04:12'),
(5, 'anandh', 'pL4lBiEkVGO4GK6HfKbj3o6tsItE52NC', '$2y$13$Xh1hbGi3rou3VRzh6ntgkuciPPA.vUj7j4DePYstvT3XrtHbaknTa', NULL, 'anandh@gmail.com', 3, 10, '0000-00-00 00:00:00', '2016-04-29 13:04:46'),
(6, 'suresh', 'A0_ZgLqVNE3bcvUvELpPi5GMTG5w_JSU', '$2y$13$ltIvtwph2J28ZsNF9FhyU.hpz4VarSM.HbsvVgMl/fVb903YU9xQW', NULL, 'suresh@gmail.com', 4, 10, '2016-04-25 12:16:12', '2016-04-29 13:06:18'),
(7, 'venkat', 'HPln5skQCA-EuE1UWTeurRGBmR5imYsl', '$2y$13$jy4fbPuQbNKDTkjbMlwXY.alL7Hw3o0HvAmSW3Xg7ErlRAKpUyqvy', NULL, 'venkat@yahoo.com', 4, 10, '2016-04-25 12:19:48', '2016-04-29 13:05:03'),
(9, 'sundar', 'C90i9WczKK5pX_Z-x0DKfb8JC05S5dck', '$2y$13$Rm3sYnOG3QWodX5Rdu6rNeWdsaFf6hg0XZdQqHZ.sf5b8E8g5BcHi', NULL, 'sundar@gmail.com', 4, 10, '2016-04-29 12:05:43', NULL),
(10, 'jaleel', 'IA7AdcG1qffPfaNZKgMN9ik3ObOeMYQZ', '$2y$13$UMn2XhfwEba/zU7R9nVZnOfWMnS5JzAxNpLg7rxSKJMUFg28q7e7C', NULL, 'jaleel@gmail.com', 4, 10, '2016-04-29 12:08:52', '2016-04-29 13:03:42'),
(11, 'zubair', 'E7DG2WBI-ppVw-66_izMxeLJfsqQaBg5', '$2y$13$8MrcNBH4Zhi081UxakL3a.e6DCgcyJKKYwFhgfHdo/bD5vVZa.74m', NULL, 'zubair@gmail.com', 3, 10, '2016-04-29 12:10:38', NULL),
(12, 'yyy', '9pX6DD9HNqmZhUSiYlhZ_t9zyZFhI1df', '$2y$13$bKa4UnGacIVQ6wPuB/77he5Ca4GP63MKHG2p6JSGDfCt2acmtBXBC', NULL, 'yyy@gmail.com', 4, 10, '2016-04-29 13:27:26', '2016-04-29 14:51:48'),
(13, 'tyty', 'ClScBsK2gFSJrOrhKTWCQTxvB6qPyAln', '$2y$13$tLyorNg5jiSXoOCoJgKthOTY.VQ3T2gqt3UZeyxcX5HRnW6krQwhe', NULL, 'tyty@gmail.com', 3, 10, '2016-04-29 13:34:16', NULL),
(14, 'fouz1', '7xRgC6oXGfZT9iNZyuGAWhXzdcCyBhRg', '$2y$13$2pT8qLFZbtzGEsxqo.P.D.LXwsHG8f3Nc9sx3b.3sXRbsF91Za906', NULL, 'fouz1@gmail.com', 3, 10, '2016-05-02 09:33:00', NULL),
(15, 'varathan', 'IZT9rBI0nEOOgsAjWhAHUrXy5cn6KwJE', '$2y$13$zmdkSIg8Zx0zfRuC.oQKO.hX88zBAORnZirNjDj8iV6aszoaiDRpO', NULL, 'varathan@gmail.com', 3, 10, '2016-05-03 17:30:06', NULL),
(16, 'pandian', 'uHj8Xq8yC1qvrTzEoonHoUKHi7jBTaMx', '$2y$13$o6nVZL09O8DCe3QGrZ3NI.G3Ugvd7KCNZQylDv.C9S6mkU4qhj7Tq', NULL, 'pandian@gmail.com', 4, 10, '2016-05-05 09:54:31', NULL),
(17, 'vishwa', 'LHlQWwOFPnhrmiVEsPBr9rTuICtF8j9e', '$2y$13$b/uaLYZuRakEigTZGG1o/O.KhCYgpqOZZs7Fn4JZqhF/cQeVyVcIm', NULL, 'vishwa@gmail.com', 4, 10, '2016-05-07 16:16:37', NULL),
(18, 'paul', 'pRSrgqhwMtJACagURhWWRzmlNjcIYPzg', '$2y$13$umT2kB5r3/M6IvwSQxt/FOONLV3SaOxE1J2f7ffwJw9LqEYWCgaey', NULL, 'paul@gmail.com', 3, 10, '2016-05-07 17:01:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_title` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`role_id`, `role_title`, `created_at`) VALUES
(1, 'Super Admin', '2016-04-25 18:45:03'),
(2, 'Sub Admin', '2016-04-25 18:45:46'),
(3, 'Staff / Teacher', '2016-04-25 18:46:13'),
(4, 'Parent', '2016-04-25 18:46:28');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `device_info`
--
ALTER TABLE `device_info`
  ADD CONSTRAINT `device_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `device_info_ibfk_2` FOREIGN KEY (`mobile_device_id`) REFERENCES `mobile_device` (`mobile_device_id`) ON UPDATE CASCADE;

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `group`
--
ALTER TABLE `group`
  ADD CONSTRAINT `group_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `group_info`
--
ALTER TABLE `group_info`
  ADD CONSTRAINT `group_info_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `group_info_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`parent_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `parents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parents_children`
--
ALTER TABLE `parents_children`
  ADD CONSTRAINT `parents_children_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`parent_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `parents_children_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `children` (`child_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `photos_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `school_user`
--
ALTER TABLE `school_user`
  ADD CONSTRAINT `school_user_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `school_user_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `user_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
