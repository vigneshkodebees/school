<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "group".
 *
 * @property integer $group_id
 * @property string $group_name
 * @property string $description
 * @property string $created_date
 * @property integer $staff_id
 *
 * @property Staff $staff
 * @property GroupInfo[] $groupInfos
 * @property Photos[] $photos
 */
class Group extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'group';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['group_name', 'description'], 'required'],
            [['created_date'], 'safe'],
            [['staff_id'], 'integer'],
            [['group_name', 'description'], 'string', 'max' => 20],
            [['staff_id'], 'exist', 'skipOnError' => true, 'targetClass' => Staff::className(), 'targetAttribute' => ['staff_id' => 'staff_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'group_name' => 'Group Name',
            'description' => 'Description',
            'created_date' => 'Created Date',
            'staff_id' => 'Staff ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStaff()
    {
        return $this->hasOne(Staff::className(), ['staff_id' => 'staff_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroupInfos()
    {
        return $this->hasMany(GroupInfo::className(), ['group_id' => 'group_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPhotos()
    {
        return $this->hasMany(Photos::className(), ['group_id' => 'group_id']);
    }
}
