<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "group_info".
 *
 * @property integer $group_id
 * @property integer $parent_id
 * @property integer $staff_id
 *
 * @property Staff $staff
 * @property Group $group
 * @property Parents $parent
 */
class Group_info extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'group_info';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['group_id', 'parent_id'], 'safe'],
            [['group_id', 'parent_id'], 'integer'],
            [['group_id'], 'exist', 'skipOnError' => true, 'targetClass' => Group::className(), 'targetAttribute' => ['group_id' => 'group_id']],
            [['parent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Parents::className(), 'targetAttribute' => ['parent_id' => 'parent_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'parent_id' => 'Parent ID',

        ];
    }




    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(Group::className(), ['group_id' => 'group_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParent()
    {
        return $this->hasOne(Parents::className(), ['parent_id' => 'parent_id']);
    }
}
