<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "parent_list".
 *
 * @property integer $list_id
 * @property integer $group_id
 * @property string $group_name
 * @property string $description
 * @property integer $parents_id
 *
 * @property Group $description0
 * @property GroupInfo $group
 * @property GroupInfo $parents
 * @property Group $groupName
 */
class ParentList extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'parent_list';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['group_id', 'group_name', 'description', 'parents_id'], 'required'],
            [['group_id', 'parents_id'], 'integer'],
            [['group_name'], 'string', 'max' => 20],
            [['description'], 'string', 'max' => 40],
            [['description'], 'exist', 'skipOnError' => true, 'targetClass' => Group::className(), 'targetAttribute' => ['description' => 'description']],
            [['group_id'], 'exist', 'skipOnError' => true, 'targetClass' => GroupInfo::className(), 'targetAttribute' => ['group_id' => 'group_id']],
            [['parents_id'], 'exist', 'skipOnError' => true, 'targetClass' => GroupInfo::className(), 'targetAttribute' => ['parents_id' => 'parent_id']],
            [['group_name'], 'exist', 'skipOnError' => true, 'targetClass' => Group::className(), 'targetAttribute' => ['group_name' => 'group_name']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'list_id' => 'List ID',
            'group_id' => 'Group ID',
            'group_name' => 'Group Name',
            'description' => 'Description',
            'parents_id' => 'Parents ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDescription0()
    {
        return $this->hasOne(Group::className(), ['description' => 'description']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(GroupInfo::className(), ['group_id' => 'group_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParents()
    {
        return $this->hasOne(GroupInfo::className(), ['parent_id' => 'parents_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroupName()
    {
        return $this->hasOne(Group::className(), ['group_name' => 'group_name']);
    }
}
