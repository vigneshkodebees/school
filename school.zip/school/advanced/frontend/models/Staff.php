<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "staff".
 *
 * @property integer $staff_id
 * @property string $staff_name
 * @property string $designation
 * @property integer $user_id
 * @property User $user
 */


class Staff extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'staff';
    }


    /**
     * @inheritdoc
     */

    public $username ;
    public $password_hash;
    public $email;


    public function rules()
    {
        return [
            [['staff_name', 'designation','username','password_hash','email',], 'required'],
            [['user_id'], 'safe'],
            [['user_id'], 'integer'],
            [['staff_name', 'designation'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'staff_id' => 'Staff ID',
            'staff_name' => 'Staff Name',
            'designation' => 'Designation',
            'user_id' => 'User ID',
            'username' => 'Username',
            'password_hash' => 'Password Hash',
            'email' => 'Email',
        ];
    }
}
