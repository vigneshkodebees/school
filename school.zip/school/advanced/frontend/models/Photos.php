<?php

namespace frontend\models;
use yii\web\UploadedFile;

use Yii;

/**
 * This is the model class for table "photos".
 *
 *@property integer $photo_id
 * @property integer $group_id
 * @property string $photo_url
 * @property integer $created_by
 * @property string $created_date
 *
 * @property User $createdBy
 * @property Group $group
 */
class Photos extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public $imageFile;

    public static function tableName()
    {
        return 'photos';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['group_id', 'photo_url','created_by'], 'safe'],
            [['group_id', 'created_by'], 'integer'],
            [['created_date'], 'safe'],
            [['imageFile'], 'file', 'skipOnEmpty' => false,'extensions' => 'png, jpg'],
            [['photo_url'], 'string', 'max' => 255],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'user_id']],
            [['group_id'], 'exist', 'skipOnError' => true, 'targetClass' => Group::className(), 'targetAttribute' => ['group_id' => 'group_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'photo_url' => 'Photo Url',
            'photo_id' => 'Photo ID',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',

        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(Group::className(), ['group_id' => 'group_id']);
    }

    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['user_id' => 'created_by']);
    }


    public function upload()
    {

        $this->photo_url = $this->imageFile->baseName . '_' . time() . '.' . $this->imageFile->extension;

        if ($this->validate()) {
            $this->save();
            $this->imageFile->saveAs(Yii::getAlias('@advanced').'\uploads'.'/' . $this->photo_url);
            return true;

        } else {

            return false;
        }
    }





}
