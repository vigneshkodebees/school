<?php

namespace frontend\controllers;

use frontend\models\User;
use Yii;
use frontend\models\Parents;
use frontend\models\Parents_children;
use frontend\models\Children;
use frontend\models\ParentsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ParentsController implements the CRUD actions for Parents model.
 */
class ParentsController extends Controller
{
    /**
     * @inheritdoc
     */


    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Parents models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ParentsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Parents model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Parents model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Parents();
        $user =new User();
        $parent_child= new parents_children;


        if ($model->load(Yii::$app->request->post()) )
        {
            $parents=$_POST['Parents'];

            $username=$parents['username'];
            $password=$parents['password_hash'];
            $email=$parents['email'];


            $child_id=$parents['child_id'];

            $user->username =$username;
            $user->password_hash = $password;
            $user->email = $email;


            $parent_child->child_id=$child_id;

//            if( $user->password_hash!=null)
//           {
//               $user->password_hash = Yii::$app->security->generatePasswordHash($user->password_hash);
//           }
//            $user->generatePasswordHash($password)
            $user->setPassword($password);
            $user->generateAuthKey();
            $user->role_id=4;
            $user->save();

            $id= $user->user_id;
            $model->user_id=$id;
            $model->save();

//the below codes to save the input in Parents_children table

            $pid=$model->parent_id;
            $parent_child->parent_id=$pid;

            $parent_child->save();
//            var_dump($model->attributes);
//            exit;
//            var_dump($user->attributes);
//            exit;
//            $model->save();

//            $user->save();
//            && $user->load(Yii::$app->request->post())
            return $this->redirect(['view', 'id' => $model->parent_id]);
        }

    else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Parents model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->parent_id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Parents model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Parents model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Parents the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Parents::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

//    public function actionMail()
//    {
//        Yii::$app->mailer->compose('contact/html', ['contactForm' => $form])
//            ->setFrom('from@domain.com')
//            ->setTo($form->email)
//            ->setSubject($form->subject)
//            ->send();
//    }

}
