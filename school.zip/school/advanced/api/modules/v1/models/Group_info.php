<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "group_info".
 *
 * @property integer $group_id
 * @property integer $parent_id
 *
 * @property Parents $parentInfo
 * @property Group $group
 */
class Group_info extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'group_info';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['group_id', 'parent_id'], 'required'],
            [['group_id', 'parent_id'], 'integer'],
            [['parent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Parents::className(), 'targetAttribute' => ['parent_id' => 'parent_id']],
            [['group_id'], 'exist', 'skipOnError' => true, 'targetClass' => Group::className(), 'targetAttribute' => ['group_id' => 'group_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'parent_id' => 'Parent ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParentInfo()
    {
        return $this->hasOne(Parents::className(), ['parent_id' => 'parent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(Group::className(), ['group_id' => 'group_id']);
    }
//    public static function findByAuthKey($group_id)
//    {
//        return ("message");
//        return static::findOne([
//            'group_id' => $group_id,
//
//        ]);
//    }


}
