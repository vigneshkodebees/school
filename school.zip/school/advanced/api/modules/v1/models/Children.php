<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "children".
 *
 * @property integer $child_id
 * @property integer $Roll_no
 * @property string $child_name
 * @property string $grade
 *
 * @property ParentsChildren[] $parentsChildrens
 */
class Children extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'children';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['Roll_no'], 'integer'],
            [['child_name', 'grade','Roll_no'], 'required'],
            [['child_name'], 'string', 'max' => 20],
            [['grade'], 'string', 'max' => 5],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'child_id' => 'Child ID',
            'Roll_no' => 'Roll No',
            'child_name' => 'Child Name',
            'grade' => 'Grade',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParentsChildrens()
    {
        return $this->hasMany(ParentsChildren::className(), ['child_id' => 'child_id']);
    }
}
