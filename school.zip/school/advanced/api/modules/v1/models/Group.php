<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "group".
 *
 * @property integer $group_id
 * @property string $group_name
 * @property string $description
 * @property string $created_date
 * @property integer $staff_id
 *
 * @property Staff $staffInfo
 * @property Group_info[] $groupDetails
 * @property Groups $groupInfo
 * @property Photos[] $photosDetail
 * @property ParentInfo[] $parentInfos
 * @property StaffInfo[] $staffInfos
 */
class Group extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'group';
    }

    /**
     * @inheritdoc
     */

    public static function primaryKey()
    {
        return ['group_id'];
    }

    public function rules()
    {
        return [
            [['group_name', 'description'], 'required'],
            [['description'], 'string'],
            [['staff_id'], 'integer'],
            [['created_date'], 'safe'],
            [['group_name'], 'string', 'max' => 20],
            [['staff_id'], 'exist', 'skipOnError' => true, 'targetClass' => Staff::className(), 'targetAttribute' => ['staff_id' => 'staff_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'group_name' => 'Group Name',
            'description' => 'Description',
            'created_date' => 'Created Date',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroupDetails()
    {
        return $this->hasMany(Group_info::className(), ['group_id' => 'group_id']);
    }

    public function getGroupInfo()
    {
        return $this->hasMany(Group::className(), ['group_id' => 'group_id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPhotosDetail()
    {
        return $this->hasMany(Photos::className(), ['group_id' => 'group_id']);
    }

    public function getStaffInfo()
    {
        return $this->hasOne(Staff::className(), ['staff_id' => 'staff_id']);
    }


}
