<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "group".
 *
 * @property integer $group_id
 * @property string $group_name
 * @property string $description
 * @property string $created_date
 *
 * @property Group_info[] $groupDetails
 * @property Photos[] $photos
 */
class Group extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'group';
    }

    /**
     * @inheritdoc
     */

    public static function primaryKey()
    {
        return ['group_id'];
    }

    public function rules()
    {
        return [
            [['group_name', 'description'], 'required'],
            [['description'], 'string'],
            [['created_date'], 'safe'],
            [['group_name'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'group_name' => 'Group Name',
            'description' => 'Description',
            'created_date' => 'Created Date',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroupDetails()
    {
        return $this->hasMany(Group_info::className(), ['group_id' => 'group_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPhotos()
    {
        return $this->hasMany(Photos::className(), ['group_id' => 'group_id']);
    }
}
