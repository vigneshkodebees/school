<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "photos".
 *
 * @property integer $group_id
 * @property string $photo_url
 *
 * @property Group $group
 */
class Photos extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */

    public $photo ;

    public static function tableName()
    {
        return 'photos';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['photo_url'], 'safe'],
            [['photo'], 'file', 'skipOnEmpty' => false, 'extensions' => 'png, jpg'],
            [['group_id'], 'exist', 'skipOnError' => true, 'targetClass' => Group::className(), 'targetAttribute' => ['group_id' => 'group_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'group_id' => 'Group ID',
            'photo_url' => 'Photo Url',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroup()
    {
        return $this->hasOne(Group::className(), ['group_id' => 'group_id']);
    }

    public function upload()
    {


        if ($this->validate()) {
            $this->photo->saveAs('uploads/' . $this->photo->baseName . '.' . $this->photo->extension);
            return true;
        } else {
            return false;
        }
    }

}
