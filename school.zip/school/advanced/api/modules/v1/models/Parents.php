<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "parents".
 *
 * @property integer $parent_id
 * @property string $parent_name
 * @property string $parent_address
 * @property string $mobile_number
 * @property integer $user_id
 *
 * @property GroupInfo[] $groupInfos
 * @property Parent_info[] $parentDetails
 * @property User $user
 * @property ParentsChildren[] $parentsChildrens
 * @property ParentInfo[] $parentInfos
 */
class Parents extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'parents';
    }

    /**
     * @inheritdoc
     */

    public static function primaryKey()
    {
        return ['parent_id'];
    }

    public function rules()
    {
        return [
            [['parent_name', 'parent_address', 'mobile_number', 'user_id'], 'required'],
            [['parent_address'], 'string'],
            [['user_id'], 'integer'],
            [['parent_name'], 'string', 'max' => 20],
            [['mobile_number'], 'string', 'max' => 12],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'parent_id' => 'Parent ID',
            'parent_name' => 'Parent Name',
            'parent_address' => 'Parent Address',
            'mobile_number' => 'Mobile Number',
            'user_id' => 'User ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGroupInfos()
    {
        return $this->hasMany(GroupInfo::className(), ['parent_id' => 'parent_id']);
    }



    /**
     * @return \yii\db\ActiveQuery
     */

    public function getParentDetails()
    {
        return $this->hasMany(Group_info::className(), ['parent_id' => 'parent_id']);
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParentsChildrens()
    {
        return $this->hasMany(ParentsChildren::className(), ['parent_id' => 'parent_id']);
    }
}
