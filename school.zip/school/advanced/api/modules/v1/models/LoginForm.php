<?php
namespace api\modules\v1\models;

use api\modules\v1\models\User;
use Yii;
use yii\base\Model;
use yii\db\Expression;

/**
 * Login form
 */
class LoginForm extends Model
{
    public $username;
    public $password;
    public $rememberMe = true;
    public $location;
    public $lat;
    public $lng;
    public $application_version;
    public $device_model;
    public $device_platform;
    public $device_uuid;
    public $device_verson;
    public $gcm_id;
    public $device_status;

    private $_user;


    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // username and password are both required
            [['username', 'password','location', 'lat', 'lng', 'application_version', 'device_model', 'device_platform', 'device_uuid', 'device_verson', 'gcm_id','device_status'], 'required'],
            // rememberMe must be a boolean value
            ['rememberMe', 'boolean'],
            // password is validated by validatePassword()
            ['password', 'validatePassword'],
        ];
    }


    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
    public function validatePassword($attribute, $params)
    {
        if (!$this->hasErrors()) {
            $user = $this->getUser();
            if (!$user || !$user->validatePassword($this->password)) {
                $this->addError($attribute, 'Incorrect username or password.');
            }
        }
    }

    /**
     * Logs in a user using the provided username and password.
     *
     * @return boolean whether the user is logged in successfully
     */
    public function login()
    {
        if ($this->validate()  && $this->mobileSave()) {
            return Yii::$app->user->login($this->getUser());
        } else {
            return false;
        }
    }

    public function mobileSave()
    {
        $user=$this->getUser();
        $mobileDevice = new MobileDevice();
        $mobileDevice->gcm_id = $this->gcm_id;
        $mobileDevice->application_version = $this->application_version;
        $mobileDevice->device_model = $this->device_model;
        $mobileDevice->device_platform = $this->device_platform;
        $mobileDevice->device_verson = $this->device_verson;
        $mobileDevice->device_uuid = $this->device_uuid;
        $mobileDevice->lat = $this->lat;
        $mobileDevice->lng = $this->lng;
        $mobileDevice->location = new Expression("GeomFromText('Point(" . $mobileDevice->lat . " " . $mobileDevice->lng . ")')");
        $user->updateDevice($mobileDevice);
//        $mobileDevice->save();
        return true;
    }

    /**
     * Finds user by [[username]]
     *
     * @return User|null
     */
    protected function getUser()
    {
        if ($this->_user === null) {
            $this->_user = User::findByUsername($this->username);
        }

        return $this->_user;
    }
}
