<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "mobile_device".
 *
 * @property integer $mobile_device_id
 * @property string $location
 * @property string $lat
 * @property string $lng
 * @property string $application_version
 * @property string $device_model
 * @property string $device_platform
 * @property string $device_uuid
 * @property string $device_verson
 * @property string $gcm_id
 * @property string $device_status
 *

 */
class MobileDevice extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'mobile_device';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['location', 'lat', 'lng', 'application_version', 'device_model', 'device_platform', 'device_uuid', 'device_verson', 'gcm_id'], 'required','on'=>'DRIVER'],
            [['location', 'lat', 'lng', 'application_version', 'device_model', 'device_platform', 'device_uuid', 'device_verson', 'gcm_id'], 'required','on'=>'EMPLOYEE'],
            [['lat', 'lng'], 'number'],
            [['gcm_id'], 'string'],
            [['device_uuid'], 'string'],
            [['application_version', 'device_model', 'device_platform', 'device_verson', 'device_status'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'mobile_device_id' => 'Mobile Device ID',
            'location' => 'Location',
            'lat' => 'Lat',
            'lng' => 'Lng',
            'application_version' => 'Application Version',
            'device_model' => 'Device Model',
            'device_platform' => 'Device Platform',
            'device_uuid' => 'Device Uuid',
            'device_verson' => 'Device Verson',
            'gcm_id' => 'Gcm ID',
            'device_status' => 'Device Status',
        ];
    }

    public function getMobileDetails()
    {
        return $this->hasMany(Group::className(), ['mobile_device_id' => 'mobile_device_id']);
    }

}
