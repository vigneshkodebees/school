<?php

namespace api\modules\v1\models;


use api\modules\v1\models\User;
use Yii;

/**
 * This is the model class for table "device_info".
 *
 * @property integer $device_info_id
 * @property integer $user_id
 * @property integer $mobile_device_id
 *
 * @property MobileDevice $mobileDevice
 * @property User $user
 */
class DeviceInfo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'device_info';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'mobile_device_id'], 'integer'],
            [['mobile_device_id'], 'exist', 'skipOnError' => true, 'targetClass' => MobileDevice::className(), 'targetAttribute' => ['mobile_device_id' => 'mobile_device_id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'device_info_id' => 'Device Info ID',
            'user_id' => 'User ID',
            'mobile_device_id' => 'Mobile Device ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMobileDevice()
    {
        return $this->hasOne(MobileDevice::className(), ['mobile_device_id' => 'mobile_device_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['user_id' => 'user_id']);
    }
}
