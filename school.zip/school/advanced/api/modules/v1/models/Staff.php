<?php

namespace api\modules\v1\models;

use Yii;

/**
 * This is the model class for table "staff".
 *
 * @property integer $staff_id
 * @property string $staff_name
 * @property string $designation
 * @property integer $user_id
 * @property User $user
 * @property Staff_info[] $staffDetails
 * @property StaffInfo[] $staffInfos

 */


class Staff extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'staff';
    }

    /**
     * @inheritdoc
     */

//    public $username ;
//    public $password_hash;
//    public $email;


    public function rules()
    {
        return [
            [['staff_name', 'designation'], 'required'],
            [['user_id'], 'safe'],
            [['user_id'], 'integer'],
            [['staff_name', 'designation'], 'string', 'max' => 20],
        ];
    }

    public static function primaryKey()
    {
        return ['staff_id'];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'staff_id' => 'Staff ID',
            'staff_name' => 'Staff Name',
            'designation' => 'Designation',
            'user_id' => 'User ID',
//            'username' => 'Username',
//            'password_hash' => 'Password Hash',
//            'email' => 'Email',
        ];
    }

    public function getStaffDetails()
    {
        return $this->hasMany(Group::className(), ['staff_id' => 'staff_id']);
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['user_id' => 'user_id']);
    }

}
