<?php

namespace api\modules\v1\controllers;


use api\modules\v1\models\Group_info;
use api\modules\v1\models\Parents;
use yii\rest\ActiveController;
use Yii;
use api\modules\v1\models\User;


class Parent_groupController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Group_info';



    public function actions()
    {
        $actions = parent::actions();
        unset( $actions['index']);
        return $actions;
    }

    public function actionIndex()
    {


        $user = User::findByAuthKey(Yii::$app->getRequest()->queryParams['auth_key']);

        $puser_id=$user['user_id'];

        $parentInfo = Parents::findOne(['user_id' => $puser_id]);

        $parent_id=$parentInfo['parent_id'];



        if ($parent_id == NULL) {

            return array("success"=>false,"message"=>"Sorry No Such Parent is Found");
        }
        else {

            foreach ($parentInfo->parentDetails as $parentDetail) {

                $groupInfo[] = $parentDetail->groupInfo->attributes;

            }
            $result = array("parentInfo" => $parentInfo, "groupList" => $groupInfo);
            return $result;
        }
    }


}
