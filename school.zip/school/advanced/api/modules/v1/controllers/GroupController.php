<?php

namespace api\modules\v1\controllers;

use api\modules\v1\models\Staff;
use yii\rest\ActiveController;
use api\modules\v1\models\User;
use Yii;


class GroupController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Group';

    public function actions()
    {
        $actions = parent::actions();
        unset( $actions['index']);
        return $actions;
    }

    public function actionIndex()
    {


        $user = User::findByAuthKey(Yii::$app->getRequest()->queryParams['auth_key']);

        $suser_id=$user['user_id'];

        $staffInfo = Staff::findOne(['user_id' => $suser_id]);

        $staff_id=$staffInfo['user_id'];





        if ($staff_id == NULL) {

            return array("success"=>false,"message"=>"Sorry No Such Staff id is Found");
        }
        else {

            foreach ($staffInfo->staffDetails as $staffDetail) {


                $groupInfo[] = $staffDetail->groupInfo;

            }
            if($groupInfo == Null)
            {
                return array("success"=>false,"message"=>"No groups is assigned with the teacher");

            }
            else {
                $result = array("parentInfo" => $staffInfo, "groupList" => $groupInfo);
                return $result;
            }
        }
    }



}

