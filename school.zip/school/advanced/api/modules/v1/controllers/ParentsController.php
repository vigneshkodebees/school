<?php

namespace api\modules\v1\controllers;

use yii\rest\ActiveController;
use Yii;
use api\modules\v1\models\User;
use api\modules\v1\models\Parents;

/**
 * Country Controller API
 *
 * @author Budi Irawan <deerawan@gmail.com>
 */
class ParentsController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Parents';

    public function actions()
    {
        $actions = parent::actions();
        unset($actions['index']);
        return $actions;
    }

    public function actionIndex()
    {


        $user = User::findByAuthKey(Yii::$app->getRequest()->queryParams['auth_key']);
        if ($user == Null) {
            return array("success"=>false,"message"=>"No such user");
        }
        else {

            $puser_id = $user['user_id'];

            $parentInfo = Parents::findOne(['user_id' => $puser_id]);
            return $parentInfo;
        }


    }
}
