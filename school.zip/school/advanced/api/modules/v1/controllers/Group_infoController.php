<?php

namespace api\modules\v1\controllers;

use api\modules\v1\models\Group_info;
use api\modules\v1\models\Group;
use api\modules\v1\models\Parents;
use yii\rest\ActiveController;
use Yii;
use api\modules\v1\models\User;


class Group_infoController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Group_info';



    public function actions()
    {
        $actions = parent::actions();
        unset( $actions['index']);
        return $actions;
    }


   public function actionIndex($group_id)
   {
       $user = User::findByAuthKey(Yii::$app->request->headers->get('auth_key'));

       if ($user == Null) {
           return array("success"=>false,"message"=>"No such user");
       }
       else {

           $groupInfo = Group::findOne(['group_id' => $group_id]);

           if ($groupInfo == Null) {
               return array("success"=>false,"message"=>"No such group id");
           }
           else {

               foreach ($groupInfo->groupDetails as $groupDetail) {

                   $parentInfo[] = $groupDetail->parentInfo->attributes;

               }
           }
           $result = array("groupInfo" => $groupInfo, "parentList" => $parentInfo);
           return $result;
       }
   }




}
