<?php

namespace api\modules\v1\controllers;

use api\modules\v1\models\Group_info;
use api\modules\v1\models\Group;
use api\modules\v1\models\Parents;
use yii\rest\ActiveController;
use Yii;

/**
 * Country Controller API
 *
 * @author Budi Irawan <deerawan@gmail.com>
 */
class Group_infoController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Group_info';



    public function actions()
    {
        $actions = parent::actions();
        unset( $actions['index']);
        return $actions;
    }


   public function actionIndex($group_id)
    {
/*
//        $model = Group_info::find()->where(['group_id' => $group_id,])->all();
//        $asd=$model->attributes;
if (!$group_id) {

return "No groups Found";
}

//       $asd = $group_id->getGroupInfos();
        $model = Group_info::find()
//            ->joinWith(['parents(parent_id)'])
//            ->select('group_id,group_name, description,')
            ->with('parent_id')
            ->asArray()
            ->where(['group_id' => $group_id,])
            ->all();

*/


        $groupInfo = Group::findOne(['group_id' => $group_id]);
        foreach ($groupInfo->groupDetails as $groupDetail)
        {
           $parentInfo[] = $groupDetail->parentInfo->attributes;
        }
        $result = array("groupInfo"=>$groupInfo,"parentList"=>$parentInfo);
        return $result;



    }


}
