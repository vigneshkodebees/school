<?php

namespace api\modules\v1\controllers;


use api\modules\v1\models\Photos;
use api\modules\v1\models\Group;
use yii\rest\ActiveController;
use yii\web\UploadedFile;
use Yii;
use yii\helpers\Url;
use api\modules\v1\models\User;



class PhotosController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Photos';

    public function actions()
    {
        $actions = parent::actions();
        unset( $actions['index']);
        unset( $actions['create']);
//        unset( $actions['uploads']);
        return $actions;
    }

    public function actionIndex($group_id)
    {
       $user = User::findByAuthKey(Yii::$app->request->headers->get('auth_key'));

        if($user==Null)
        {
            return array("success"=>false,"message"=>"No such user");
        }
        else{

            $groupInfo =Photos::findAll(['group_id' => $group_id]);
            foreach($groupInfo as $g1) {
                $g1->photo_url = Url::to('/school/advanced/uploads/' . $g1->photo_url, true);

            }



            if($groupInfo==Null){

                return array("success"=>false,"message"=>"No Photos in this group");
            }
            else{

                return $groupInfo;
            }

        }






    }

    public function actionCreate()
    {
        $user = User::findByAuthKey(Yii::$app->request->headers->get('auth_key'));


        if($user==Null)
        {
            return array("success"=>false,"message"=>"No such user");
        }
        else {
            $userInfo=$user['user_id'];

            $model = new Photos();
                $model->created_by=$userInfo;
            if ($model->load(\Yii::$app->getRequest()->getBodyParams(), '')) {
                $model->imageFile = UploadedFile::getInstanceByName('imageFile');
                $model->upload();
                return array("success"=>true,"message"=>"Photo uploaded Successfully");
            }
        }

    }




}