<?php

namespace api\modules\v1\controllers;

use api\modules\v1\models\Photos;
use yii\rest\ActiveController;
use yii\web\UploadedFile;
use Yii;

/**
 * Country Controller API
 *
 * @author Budi Irawan <deerawan@gmail.com>
 */
class PhotosController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Photos';

//    public function actions() {
//        $actions = parent::actions();
//        unset($actions['create']);
//        return $actions;
//    }
//
//    public function actionCreate()
//    {
//        try
//        {
//            $xml = new SimpleXMLElement(file_get_contents("php://input"));
//
//            $decodedImage = base64_decode($xml->headshot);
//
//            file_put_contents("full/path/to/new/image.jpg", $decodedImage);
//        }
//        catch (Exception $exception)
//        {
//            echo $exception->getMessage();
//        }
//    }


    public function actionUpload()
    {
        $model = new Photos();

        if (Yii::$app->request->isPost) {
            $model->photo = UploadedFile::getInstance($model, 'photo');
          
            if ($model->upload()) {
                // file is uploaded successfully
                $result = array("status"=>true,"message"=>"Photo uploaded successfully");
                return $result;
            }
            else{
                $result = array("status"=>false,"message"=>"Photo not uploaded","error"=>$model->getErrors());
                return $result;
            }

        }


    }

}