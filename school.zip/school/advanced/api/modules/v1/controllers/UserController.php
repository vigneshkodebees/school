<?php
namespace api\modules\v1\controllers;



//use api\modules\v1\models\EmployeeLoginForm;

use common\models\LoginForm;
//use common\models\UserIdentity;
//use application\models\DriverInfo;
//use application\models\EmployeeUser;
use yii\rest\ActiveController;
use common\models\User;
use Yii;
//use common\helpers\RestHelper;



/**
 * Site controller
 */
class UserController extends ActiveController
{
    public $modelClass = 'api\modules\v1\models\Staff';


    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    public function actionLogin()
    {

        $model = new LoginForm();


        if ($model->load(\Yii::$app->getRequest()->getBodyParams(),'') && $model->login()) {
            $auth = \Yii::$app->user->identity->getAuthKey();
            $user = User::findByRegisteredUserId(\Yii::$app->user->getId());
            $profile = [];
            if($user->profile)
            {
                $profile['username'] = $user->profile->username;
                $profile['email']=$user->profile->email;
//                $profile['mobile_number']=$user->profile->mobile_number;
//                if($user->driverInfo) {
//                    $profile['license_number'] = $user->driverInfo->license_number;
//                }
//                if($user->driverVehicleClient)
//                {
//                    $profile['vehicle_code']=$user->driverVehicleClient->vehicleInfo->vehicle_code;
//                    $profile['register_number'] =$user->driverVehicleClient->vehicleInfo->register_number;
//                    $profile['vehicle_type']=$user->driverVehicleClient->vehicleInfo->vehicleType->type_name;
//                    $profile['driving_for']=$user->driverVehicleClient->vendorAssignment->client->name;
//                    $profile['help_desk_number']=$user->driverVehicleClient->vendorAssignment->client->helpdesk_number;
//                }

            }


            $result = array(
                'token' => $auth,
                'Message' => "Device Information saved",
                'profile'=>$profile
            );
            return $result;
//            RestHelper::sendResult($result);
        }


        else{
            return   $model->getErrors();

        }

    }


    public function actionLogout()
    {

        $user = User::findByAuthKey(Yii::$app->getRequest()->queryParams['access-token']);
        if(!$user)
        {
          return  $error="Invalid token";
//            RestHelper::sendError($error,RestHelper::INVALID_TOKEN);
        }

        $user->login_status=User::STATUS_LOGGED_OUT;
        $user->save();
        Yii::$app->user->logout();
        $result = array(
            'message' => "Logged out successfully",

        );
        return $result;

    }
//    public function actionTest()
//    {
//
//        $params= \Yii::$app->getRequest()->getBodyParams();
//        SmsApi::sendSMS("9159053006",$params['message']);
//        // SmsApi::composeMessage(SmsApi::PICKUP_CONFIRMATION_TEMPLATE,\Yii::$app->getRequest()->getBodyParams());
//        RestHelper::sendResult($params);
//    }



}