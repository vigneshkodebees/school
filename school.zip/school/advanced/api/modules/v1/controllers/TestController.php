<?php

namespace api\modules\v1\controllers;

use api\modules\v1\models\Children;
use api\modules\v1\models\Parents;
use yii\db\Expression;
use yii\rest\ActiveController;
use api\modules\v1\models\LoginForm;
//use common\models\User;
use api\modules\v1\models\User;
use api\modules\v1\models\MobileDevice;
use yii\web\UploadedFile;
use Yii;
use api\modules\v1\models\Photos;


class TestController extends ActiveController
{
    public $modelClass = 'common\models\User';

    public function actionLogin()
    {


        $model = new LoginForm();

        if ($model->load(\Yii::$app->getRequest()->getBodyParams(),'') && $model->login()) {

            $auth = \Yii::$app->user->identity->getAuthKey();
            $user = User::findByRegisteredUserId(\Yii::$app->user->getId());
            $profile['username'] = $user['username'];
            $profile['email']= $user['email'];

            $result = array(
                'token' => $auth,
                'Message' => "Device Information saved",
                'profile'=>$profile

            );
            return $result;
        }


        else{
            return   $model->getErrors();

        }

    }


    public function actionStafflogin()
    {


        $model = new LoginForm();

        if ($model->load(\Yii::$app->getRequest()->getBodyParams(),'') && $model->login()) {

            $auth = \Yii::$app->user->identity->getAuthKey();
            $user = User::findByRegisteredUserId(\Yii::$app->user->getId());
            $profile['username'] = $user['username'];
            $profile['email']= $user['email'];

            $result = array(
                'token' => $auth,
                'Message' => "Device Information saved",
//                'profile'=>$profile

            );
            return $result;
        }


        else{
            return   $model->getErrors();

        }

    }


}

