<?php
/**
 * Created by PhpStorm.
 * User: Kodebees
 * Date: 4/4/2016
 * Time: 2:21 PM
 */
Yii::setAlias('api', dirname(dirname(__DIR__)) . '/api'); // add api alias