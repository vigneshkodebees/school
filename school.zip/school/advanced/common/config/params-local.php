<?php
Yii::setAlias('@advanced', realpath(dirname(__FILE__).'/../../'));
return [
];
